"""Osculating elements, JPL SBDB (full precision), epoch JD 2461200.5 TDB (2026-06-21),
J2000 ecliptic. Fetched 2026-10-25 from https://ssd-api.jpl.nasa.gov/sbdb.api?full-prec=1&sstr=N
Planets: JPL 'Approximate Positions of the Planets', Table 1 (J2000 values, 1800-2050 fit),
https://ssd.jpl.nasa.gov/planets/approx_pos.html"""
AST = {  # name: (a AU, e, i deg, node deg, arg peri deg, symbol)
    "Ceres":  (2.765552595034094, 0.07969229514816586, 10.58802780183462, 80.24862682043221, 73.29421453021587, "⚳"),
    "Pallas": (2.769559010737709, 0.2307000995648547, 34.93279321851542, 172.8866193357694, 310.9699161652136, "⚴"),
    "Juno":   (2.670989527103278, 0.2556999836681878, 12.98659236598085, 169.8115953492418, 247.8950743075613, "⚵"),
    "Vesta":  (2.361365965127599, 0.09020374382834395, 7.143925545058711, 103.701293265032, 151.4686478221564, "⚶"),
}
# planets: a, e, i, node, long.peri (J2000)
PLAN = {
    "Mars":    (1.52371034, 0.09339410, 1.84969142, 49.55953891, -23.94362959),
    "Jupiter": (5.20288700, 0.04838624, 1.30439695, 100.47390909, 14.72847983),
}
