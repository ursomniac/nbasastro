import numpy as np
def orbit_xyz(a,e,i,O,w,n=721):
    nu=np.linspace(0,2*np.pi,n)
    r=a*(1-e**2)/(1+e*np.cos(nu))
    i,O,w=map(np.radians,(i,O,w))
    u=w+nu
    x=r*(np.cos(O)*np.cos(u)-np.sin(O)*np.sin(u)*np.cos(i))
    y=r*(np.sin(O)*np.cos(u)+np.cos(O)*np.sin(u)*np.cos(i))
    z=r*np.sin(u)*np.sin(i)
    return x,y,z
def normal(i,O):
    i,O=np.radians(i),np.radians(O)
    return np.array([np.sin(i)*np.sin(O),-np.sin(i)*np.cos(O),np.cos(i)])
def r_in_direction(el,v):
    a,e,i,O,w=el[:5]
    x,y,z=orbit_xyz(a,e,i,O,w,20001); P=np.vstack([x,y,z]).T
    d=P/np.linalg.norm(P,axis=1)[:,None]
    k=np.argmax(d@v); return np.linalg.norm(P[k])
