"""Orbits of the first four asteroids: top-down (ecliptic) and edge-on views.
Elements: JPL SBDB osculating, epoch 2026-06-21 (see elements.py). Mars/Earth: JPL approx
elements (J2000). The line where the orbital planes of Ceres and Pallas meet is computed from
their elements; seen from the Sun it points into Virgo (one way) and Cetus (the other)."""
import numpy as np
import matplotlib.pyplot as plt
from nbas_style import use, save
from elements import AST, PLAN
from orbit import orbit_xyz, normal
c = use()

style = {  # colour, linestyle, width
    "Ceres":  (c["b"], "-", 2.0),
    "Pallas": (c["a"], "-", 2.4),
    "Juno":   (c["ink"], (0, (5, 3)), 1.6),
    "Vesta":  (c["muted"], (0, (1, 2.5)), 2.0),
}
orb = {n: orbit_xyz(*v[:5]) for n, v in AST.items()}

def planet(n):
    a, e, i, O, lp = PLAN[n]
    return orbit_xyz(a, e, i, O, lp - O)
earth = orbit_xyz(1.00000261, 0.01671123, 0.0, 0.0, 102.93768193)
mars = planet("Mars")

# Ceres-Pallas plane intersection
L = np.cross(normal(AST["Ceres"][2], AST["Ceres"][3]), normal(AST["Pallas"][2], AST["Pallas"][3]))
L /= np.linalg.norm(L)
if L[2] < 0: L = -L          # +L = Virgo side (north of ecliptic), -L = Cetus side

fig = plt.figure(figsize=(7.2, 3.55))
axT = fig.add_axes([0.0, 0.02, 0.52, 0.86])
axE = fig.add_axes([0.53, 0.02, 0.46, 0.86])
for ax in (axT, axE):
    ax.set_aspect("equal"); ax.axis("off")

# ---- top-down
R = 3.75
for (x, y, z), lab in ((earth, "Earth"), (mars, "Mars")):
    axT.plot(x, y, color=c["muted"], lw=0.9, ls=(0, (2, 2)))
axT.text(0, -1.0, "Earth", ha="center", va="top", fontsize=9.5, color=c["muted"])
axT.text(0, -1.68, "Mars", ha="center", va="top", fontsize=9.5, color=c["muted"])
axT.plot([0], [0], marker="o", ms=7, color=c["strong"])
d = L[:2] / np.linalg.norm(L[:2])
axT.plot([-4.75*d[0], 4.75*d[0]], [-4.75*d[1], 4.75*d[1]], color=c["muted"], lw=0.9)
for s_, lab in ((1, "toward Virgo"), (-1, "toward Cetus")):
    px, py = 4.75*s_*d[0], 4.75*s_*d[1]
    axT.text(px, py + 0.12, lab.replace(" ", "\n"), ha="left" if px < 0 else "right", va="bottom",
             fontsize=9.5, color=c["ink"])
for n, (x, y, z) in orb.items():
    col, ls, lw = style[n]
    axT.plot(x, y, color=col, ls=ls, lw=lw)
axT.set_xlim(-4.8, 4.8); axT.set_ylim(-3.45, 3.45)
fig.text(0.26, 0.93, "From above (looking down on the ecliptic)", ha="center", fontsize=10.5)

# ---- edge-on: look along Pallas's line of nodes, so its tilt shows at full size
Op = np.radians(AST["Pallas"][3])
h = np.array([np.cos(Op + np.pi/2), np.sin(Op + np.pi/2), 0.0])
axE.axhline(0, color=c["rule"], lw=1.0)
axE.text(-3.75, -0.1, "plane of\nEarth's orbit", fontsize=9.5, color=c["muted"], va="top")
axE.plot([0], [0], marker="o", ms=7, color=c["strong"])
for n, (x, y, z) in orb.items():
    col, ls, lw = style[n]
    axE.plot(x*h[0] + y*h[1], z, color=col, ls=ls, lw=lw)
axE.set_xlim(-3.8, 3.8); axE.set_ylim(-2.6, 2.6)
fig.text(0.76, 0.93, "Edge-on, true tilts (no vertical stretch)", ha="center", fontsize=10.5)
axE.text(0.55, 2.15, "Pallas, tilted 35°", fontsize=9.5, color=c["a"], ha="left")
axE.plot([0, 3.4], [0, 0], color=c["rule"], lw=0)  # spacer

# legend (one, shared) with symbols
from matplotlib.lines import Line2D
hand = [Line2D([], [], color=style[n][0], ls=style[n][1], lw=style[n][2]) for n in AST]
labs = [f"{AST[n][5]} {n}" for n in AST]
axE.legend(hand, labs, loc="lower right", frameon=False, handlelength=2.6, prop=dict(family=["Liberation Sans", "DejaVu Sans"], size=10))
save(fig, "fig-four-orbits")
