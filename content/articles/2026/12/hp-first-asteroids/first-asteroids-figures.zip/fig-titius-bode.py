"""Titius-Bode rule vs actual mean distances.
Rule: (0,3,6,...,384 + 4)/10. Actual: semi-major axes, JPL 'Approximate Positions of the
Planets' Table 1 (J2000); Ceres from JPL SBDB (osculating, 2026)."""
import matplotlib.pyplot as plt
from matplotlib.ticker import FixedLocator, NullLocator
from nbas_style import use, save
c = use()

names = ["Mercury", "Venus", "Earth", "Mars", "Ceres", "Jupiter", "Saturn", "Uranus", "Neptune"]
k = [0, 3, 6, 12, 24, 48, 96, 192, 384]
rule = [(x + 4) / 10 for x in k]
actual = [0.38709927, 0.72333566, 1.00000261, 1.52371034, 2.765552595,
          5.20288700, 9.53667594, 19.18916464, 30.06992276]
x = list(range(len(names)))

fig, ax = plt.subplots(figsize=(7.2, 3.9))
fig.subplots_adjust(left=0.09, right=0.98, top=0.95, bottom=0.11)
ax.set_yscale("log")
ax.set_ylim(0.25, 60)
ax.yaxis.set_major_locator(FixedLocator([0.3, 0.5, 1, 2, 5, 10, 20, 50]))
ax.yaxis.set_minor_locator(NullLocator())
ax.set_yticklabels(["0.3", "0.5", "1", "2", "5", "10", "20", "50"])
ax.set_ylabel("Distance from the Sun (AU, log scale)")
ax.grid(axis="y")
ax.set_xticks(x)
ax.set_xticklabels(names)
ax.set_xlim(-0.6, 8.6)
for t in ax.get_xticklabels():
    if t.get_text() == "Ceres":
        t.set_color(c["a"]); t.set_fontweight("bold")

ax.plot(x, rule, ls="--", lw=1.2, color=c["muted"], zorder=1)
ax.plot(x, rule, ls="none", marker="o", ms=11, mfc="none", mec=c["a"], mew=1.8,
        label="Titius–Bode rule", zorder=3)
ax.plot(x, actual, ls="none", marker="D", ms=6, color=c["b"],
        label="Actual mean distance", zorder=4)

kw = dict(fontsize=9.5, color=c["ink"])
ax.annotate("Nothing known here\nuntil Ceres, 1801:\nrule 2.8, actual 2.77",
            xy=(4, 2.8), xytext=(3.0, 7.5), ha="center",
            arrowprops=dict(arrowstyle="-", color=c["muted"], lw=0.8), **kw)
ax.annotate("Uranus, 1781:\nrule 19.6, actual 19.2",
            xy=(7, 19.6), xytext=(5.55, 32), ha="center",
            arrowprops=dict(arrowstyle="-", color=c["muted"], lw=0.8), **kw)
ax.annotate("Neptune, 1846:\nrule 38.8, actual 30.1",
            xy=(8, 30.07), xytext=(7.55, 4.6), ha="center",
            arrowprops=dict(arrowstyle="-", color=c["muted"], lw=0.8), **kw)
ax.legend(loc="upper left", frameon=False, fontsize=9.5)
save(fig, "fig-titius-bode")
