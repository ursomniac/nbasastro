"""Number of known asteroids, 1800-1860.
Discovery dates of (1)-(62): IAU Minor Planet Center, 'Discovery Circumstances: Numbered Minor
Planets (1)-(5000)', https://minorplanetcenter.net/iau/lists/NumberedMPs000001.html
(retrieved 2026-10-26). All of (1)-(62) were found by 1860-09-14; (63) Ausonia is 1861."""
import datetime as dt
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from nbas_style import use, save
c = use()

D = """1801-01-01 1802-03-28 1804-09-01 1807-03-29 1845-12-08 1847-07-01 1847-08-13 1847-10-18
1848-04-25 1849-04-12 1850-05-11 1850-09-13 1850-11-02 1851-05-19 1851-07-29 1852-03-17
1852-04-17 1852-06-24 1852-08-22 1852-09-19 1852-11-15 1852-11-16 1852-12-15 1853-04-05
1853-04-06 1853-05-05 1853-11-08 1854-03-01 1854-03-01 1854-07-22 1854-09-01 1854-10-26
1854-10-28 1855-04-06 1855-04-19 1855-10-05 1855-10-05 1856-01-12 1856-02-08 1856-03-31
1856-05-22 1856-05-23 1857-04-15 1857-05-27 1857-06-27 1857-08-16 1857-09-15 1857-09-19
1857-09-19 1857-10-04 1858-01-22 1858-02-04 1858-04-04 1858-09-10 1858-09-10 1857-09-09
1859-09-22 1860-03-24 1860-09-12 1860-09-14 1860-09-09 1860-09-14""".split()
d = sorted(dt.date.fromisoformat(x) for x in D)
assert len(d) == 62
start, end = dt.date(1800, 1, 1), dt.date(1861, 1, 1)
xs, ys = [start], [0]
for k, day in enumerate(d, 1):
    xs.append(day); ys.append(k)
xs.append(end); ys.append(len(d))

fig, ax = plt.subplots(figsize=(7.2, 3.6))
fig.subplots_adjust(left=0.08, right=0.97, top=0.95, bottom=0.11)
ax.axvspan(dt.date(1807, 3, 29), dt.date(1845, 12, 8), color=c["rule"], alpha=0.45, lw=0)
ax.step(xs, ys, where="post", color=c["a"], lw=2.2)
ax.set_xlim(start, end); ax.set_ylim(0, 66)
ax.xaxis.set_major_locator(mdates.YearLocator(10))
ax.xaxis.set_major_formatter(mdates.DateFormatter("%Y"))
ax.set_ylabel("Known asteroids")
ax.grid(axis="y")

kw = dict(fontsize=9.5, color=c["ink"])
ax.annotate("Ceres, Pallas, Juno, Vesta\n1801–1807", xy=(dt.date(1807, 3, 29), 4),
            xytext=(dt.date(1801, 6, 1), 17), arrowprops=dict(arrowstyle="-", color=c["muted"], lw=0.8), **kw)
ax.text(dt.date(1826, 6, 1), 8.5, "38 years: nothing new", ha="center", **kw)
ax.annotate("Astraea, 1845\n(Hencke)", xy=(dt.date(1845, 12, 8), 5),
            xytext=(dt.date(1836, 1, 1), 24), ha="center",
            arrowprops=dict(arrowstyle="-", color=c["muted"], lw=0.8), **kw)
ax.annotate("15 by 1851:\ntoo many symbols", xy=(dt.date(1851, 7, 29), 15),
            xytext=(dt.date(1840, 6, 1), 42), ha="center",
            arrowprops=dict(arrowstyle="-", color=c["muted"], lw=0.8), **kw)
ax.annotate("62 by 1860", xy=(dt.date(1860, 9, 14), 62),
            xytext=(dt.date(1851, 1, 1), 58), ha="center",
            arrowprops=dict(arrowstyle="-", color=c["muted"], lw=0.8), **kw)
save(fig, "fig-asteroid-count")
